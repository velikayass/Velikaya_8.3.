<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<style type="text/css">
		<?php include "style.css";?>
	</style>
	
	<title>Главная</title>

</head>
<body>
	<?php include 'views/'.$content_view;?>
</body>
</html>